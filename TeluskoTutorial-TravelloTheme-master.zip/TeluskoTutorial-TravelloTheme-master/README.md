# TeluskoTutorial-TravelloTheme

![image](https://user-images.githubusercontent.com/56973897/110204720-c6318a00-7e9e-11eb-8c69-3188fb2520bc.png)

This  theme is no more free now, that's why from this repo you will get this theme at free of cost. 
Here i have attached only important things. 



